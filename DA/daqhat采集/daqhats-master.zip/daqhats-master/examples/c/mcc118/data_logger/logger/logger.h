#ifndef LOGGER_H_INCLUDED
#define LOGGER_H_INCLUDED

#include <gtk/gtk.h>
#include <glib.h>

#include "daqhats/daqhats.h"

// Global Variables
extern GtkWidget *window;
extern GMainContext *context;

#endif // LOGGER_H_INCLUDED
